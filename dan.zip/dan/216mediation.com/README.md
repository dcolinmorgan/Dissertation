# portfolio_template_bootstrap
This template can be used to create a personal webpage. 

It is developed using Twitter's Bootstrap framework and is completely resposive. 

Feel free to download/modify this template to fit for your personal needs.

A live preview of the template can be seen by clicking on the following link:

https://rawgit.com/gupta235/portfolio_template_bootstrap/master/index.html

An enhancement to this template can be found here (https://github.com/gupta235/bootstrap_email/). The enhancement has backend support for contact form (created using PHP)
