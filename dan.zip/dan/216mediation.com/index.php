<?php

  if($_POST["submit"]) {

    if(!$_POST['name']) {
        $error="<br />Please enter your name"; 
    }

    if (!$_POST['email']) {
        $error.="<br />Please enter your email address";
     }

    if (!$_POST['subject']) {
        $error.="<br />Please enter your subject";
     }

    if (!$_POST['message']) {
        $error.="<br />Please enter your message";
     }


    if ($_POST['email']!="" AND !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
       $error.="<br />Please enter a valid email address";
     }
      
    if ($error) {
       $result='<div class="alert alert-danger"><strong>There were error(s) in your form:</strong>'.$error.'</div>';
     } else {

                $emailTo="cynthia@216mediation.com";

                $subject = $_POST["subject"];

                $body= $_POST["message"];

                $headers="Sender's email address: ".$_POST["email"];


         if (mail($emailTo, $subject, "Name: ".$_POST['name'].
                                    " Email: ".$_POST['email'].
                                    " Message: ".$_POST['message'])) {

        $result='<div class="alert alert-success"><strong>Thank you!</strong> I\'ll be in touch soon.</div>';

      } else {

        $result='<div class="alert alert-danger">Sorry, there was an error sending your message. Please try again later.</div>';

     }
   }

  }

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Cynthia Bond Morgan, J.D.</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link href="css/custom.css" rel="stylesheet" type="text/css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom CSS -->
    <link href="css/scrolling-nav.css" rel="stylesheet">

    <link id="scrollUpTheme" rel="stylesheet" href="css/tab.css">
    <link rel="stylesheet" href="css/labs.css">

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-25747820-4', 'auto');
  ga('send', 'pageview');

</script>
  </head>

  <body id="page-top" data-spy="scroll" data-target=".navbar-collapse">
    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top ">
      <div class="container">

        <div class="navbar-header page-scroll">
             <a href="#home" class="navbar-brand logo page-scroll">Cynthia Bond Morgan, J.D.</a>
             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="page-scroll" href="#home"></a>        
        </div>

        <div id="navbar" class="navbar-collapse collapse navbar-right">
<ul class="nav navbar-nav">
<li class="active"><a href="#home" class="page-scroll">Home</a></li>
<li><a href="#mission" class="page-scroll">Mission</a/></li>
<li><a href="#motivation" class="page-scroll">Motivation</a></li>
<li><a href="#projects" class="page-scroll">Projects</a></li>    
<li><a href="#resume" class="page-scroll">Resume</a></li>
<li><a href="#contact" class="page-scroll">Contact</a></li>

          </ul>
        </div>

      </div>
    </div>


        <div class="container contentContainer " id="home">
                <div class="row homePageTop ">
                    <div class="image_description">
                        <div class="col-md-6">
                            <div id="circular" class="text-center ">
                                <img src="images/fam.jpg" alt="Cynthia Morgan" id="profile_image">
                            </div>
                        </div>

                        <div class="col-md-6 short_description space2 ">
                            <p> Hi, I'm Cynthia.</p><p>Attorney, Mediator, Guardian ad Litem, Parenting Coordinator, Al-Anon Member</p><p>I felt compelled to write my book and make this site in its support in order to bring together my professional and personal experience working to eleviate and mitigate pain in childhood, to present parents and children <em>dealing with addiction</em> <strong>a language, a voice, and tools</strong>, with which to <em>transform childhood trauma</em> into functional experiences.<p>I received my bachelors degree from <a href="https://www.ohio.edu/" target="_blank"><span class="color_3">Ohio University, Athens</span></a>, and my law degree from <a href="https://www.law.csuohio.edu/" target="_blank"><span class="color_3">Cleveland-Marshall College of Law</span></a></p> <p> Follow Links to <a href="https://216mediation.wordpress.com/"target="blank"><span class="color_3">my current writing project</span></a> and past projects.</p>
                        </div>

                    </div>     
                </div>
        </div>
      <div class="container">
            <div class=" contentContainer whatsnewPageTop" id="mission">
              <div class="row whatsnewPageText">
                  <h2>Mission Statement</h2>
                  <ul>
                      <div class="whatsNewli"> To promote proficient and skillful representation of the interests of children and others before the Juvenile Court, to vindicate their rights, and achieve their best interests as valued members of our community. This cite in <em>not</em> about research.  In fact, there is currently no methodology explaining how children might live through or otherwise bypass childhood trauma, caused by addiction or otherwise, to become functioning members of our society.  Currently we still allow children to endure such trauma, without giving age appropriate language to these events.  Here and in my book, I present this material because I, and now some others, have learned to transform traumatic experiences so that a child can grown through and develop healthy behaviors and habits to deal with and move past trauam.</div></div><div class="row whatsnewPageText"><h3> I now feel the urgent need to teach and share.</h3><ul><div class="whatsNewli">If you are seeking parenting skills to assist you in raising sober sons and daughters, <em>you are in the right place</em>.  Here you will find <strong>language</strong> and <strong>methods</strong>, not research and theories.

                   <!--   <li class="whatsNewli">LINK.
                      <li class="whatsNewli">LINK.-->
                  </ul>          
             </div>
            </div>
        </div>

         <div class="container">
            <div class=" contentContainer whatsnewPageTop" id="motivation">
              <div class="row whatsnewPageText">
                  <h2>Motivation</h2>
                  <ul>
                      <div class="whatsNewli">Author, Toni Morrison, was recently <a href="http://www.npr.org/2015/04/20/400394947/i-regret-everything-toni-morrison-looks-back-on-her-personal-life" target="_blank"><span class="color_3">interviewed on NPR</span></a>.  I froze when she expressed these words, “The entire time I was raising my children, I was sure I was doing everything right.  I now grieve because I was doing everything wrong.” </div>
                      <div class="whatsNewli">It is 2015, we no longer have to raise our children blindly under the guise of misunderstanding addiciton, the behaviors it invokes and the long last repercussions it has on our society's children. </div>  

<div class="whatsNewli">Please <a href="#contact" class="page-scroll">contact my office</a></li> and we can begin to discover a path forward, for yourself and more importantly, for the children you love, and possibly even for the addicted or recovering people in your lives.</div>
<ul>
                        <li class="whatsNewli"> <a href="https://books.google.se/books?id=088qDGjiJFUC&pg=PA26&lpg=PA26&dq=Child+Care+Providers+specializing+in+Recovery&source=bl&ots=GRC_IBK4xD&sig=5J0HcrMA2aMDcLJumn1TAcOmxTs&hl=en&sa=X&ved=0CDoQ6AEwA2oVChMIgP2xjaraxwIVxdcsCh1OXAkl#v=onepage&q=Child%20Care%20Providers%20specializing%20in%20Recovery&f=false"><span class="color_3">Indications of the <strong>positive feedback </strong> effect on mothers</span></a>

                        <li class="whatsNewli"> <a href="https://www.psychologytoday.com/blog/insight-therapy/201109/dealing-childhood-trauma-in-adult-therapy-facts-and-fo" target="_blank"><span class="color_3">Dealing with Childhood Trauma in Adult Therapy: Facts and Fo</span></a>
<li class="whatsNewli"> <a href="http://www.nctsn.org/resources/audiences/school-personnel/trauma-toolkit"><span class="color_3">Child Trauma Toolkit</span></a>

<li class="whatsNewli"> <a href="http://www.al-anon.org/"><span class="color_3">Al-Anon</span></a>
                        <li class="whatsNewli"> <a href="http://al-anon.org/for-alateen"><span class="color_3">Ala-teen</span></a>

                    <!--  <li class="whatsNewli">LINK.
                      <li class="whatsNewli">LINK. -->
                  </ul>          
             </div>
            </div>
        </div>


      <div class="container">
          <div class="contentContainer" id="projects">
            <div class="resumePageTop">

                  
                    <div><h2 id="project_page">Projects</h2></div>                    

                    <div>
                          <div class="project_title">
                              <h2><font color="#F0CA43">01</font> <a href="http://edwinsrestaurant.org/"target="_blank"><span class="color_3">Edwins Leadership &amp Restaurant Institute<span></a></h2>
                          </div>
                          <div class="project_description">EDWINS Leadership &amp Restaurant Institute is a unique approach at giving formerly-incarcerated adults a foundation in the hospitality industry  while providing a support network necessary for a successful reentry. EDWINS goals is to enhance the community of Cleveland’s vulnerable neighborhoods by providing its future leaders. Our mission is to teach a skilled trade in the culinary arts, empower willing minds through passion for the hospitality industry and prepare students for a successful transition into the world of business professionals.</div>
                    </div>

                    <div>
                          <div class="project_title">
                              <h2><font color="#F0CA43">02</font> <a href="http://www.promise-academy.com/"target="_blank"><span class="color_3">Promise Academy <span></a></h2>
                          </div>
                          <div class="project_description">Promise Academy was created in January of 2007 to ensure the academic success of the non-traditional student in the Greater Cleveland area.  At Promise Academy there are certified and dedicated teachers that care about students.  All teachers, administrative staff and counselors promise to assist students in reaching their highest potential by providing wrap around services to help them stay in school.  Our expanded goal is to link students with educational experiences that will connect them to a college or a career.  One of the unique features of Promise Academy is an accelerated track for students to complete additional credits in a given year.  This opportunity affords students a chance to complete more credits than they would have in a traditional high school.  We support students with innovative online, computer based, modular learning curriculum and flexible hours.</div>
                    </div>

                   
                  

                          <div class="project_title">
                              <h2><font color="#F0CA43">03</font> <a href="http://guardianadlitemproject.org/"><span class="color_3">Cuyahoga County Guardian ad Litem project<span></a></h2>
                          </div>
                          <div class="project_description">The Guardian ad Litem Project was formed in 1978 in response to legislation requiring the appointment of a guardian ad litem (GAL) in all abuse and neglect cases, as well as in other juvenile court cases in which there is a parent/child conflict, where the child has no parent, where the parent is a minor or appeared to be mentally incompetent, or where appointment is otherwise necessary to ensure a fair hearing.
The Guardian ad Litem Project recruits and trains GALs and monitors their performance. The Project serves as the liaison between the GALs, the Juvenile Court, and the public. The Project operates according to its By-Laws under an Administrator and Advisory Committee. Throughout the years, the Advisory Committee has been comprised of attorneys, psychologists, college faculty, social workers, foster parents, and members of valued community organizations. The Executive Director of the Bar Association, the Program Director of Mediation, and the Juvenile Court Administrative Judge and Director of Court Services serve as ex-officio members of the Advisory Committee.</div>
                    </div>           
            </div>
           </div> 
        </div>

        <div class="container"> 
          <div class="contentContainer " id="resume">
            <div class="resumePageTop">

              <!-- Work  -->
              <div class="work">
                  <div class="row">
                    <div class="col-md-2 work_class "><h4>Work</h4></div>
                    <div class="col-md-7 ">
                      <div class="job">
                        <div class="position_title">Private Practice Attorney</div>
                        <div class="company_title">Morgan Mediation</div>
                        <div class="job_period">1999 - Present</div>
		<div class="job_details"><p>Specializing in Domestic Relations Law, Juvenile Law, Custody Law, Dependency, Neglect and Abuse Law. <li>Guardian Ad Litem, Assigned Counsel, Guardian Ad Litem for Cuyahoga County Department of Justice Affairs Office of Mediation, Guardian Ad Litem for Cuyahoga County Juvenile Drug Court. </p>
</div>
                      </div>
                      <div class="job">
                        <div class="position_title">Custody Mediation Project</div>
                        <div class="company_title"><a href="http://juvenile.cuyahogacounty.us/" target="_blank"><span class="color_3">Cuyahoga County Juvenile Court</span></a></div>
                        <div class="job_period">1996 - 2003</div>
                        <div class="job_details"><p>Mediator, Advisory Board Member, Strategic Planning Chair</p><p> <li>Mediated over 100 cases annually involving private child custody, dependency, neglect, and abuse with over 83% success rate.</li> <li>Participated in monthly Juvenile Court Custody Mediation Project Advisory Board meetings as a Board Member to increase projects productivity, expand programs, increase mediator educational training and increase mediation visibility throughout the Cuyahoga County legal system.</li><li>  Chaired the Juvenile Court Custody Mediation Project’s Strategic Planning Committee in expanding the court’s use of mediation throughout the Juvenile Court with the goal of expanding mediation into Cuyahoga County Court of Common Pleas Domestic Relations and Probate Courts divisions.</p>
</p></div>
                      </div>
                      <div class="job">
                        <div class="position_title">Attorney, Assigned Counsel and Guardian ad Litem
</div>
                        <div class="company_title"><a href="http://www.hartory.com/" target="_blank"<span class="color_3">Timothy P. Hartory & Associates</span></a></div>
                        <div class="job_period">1992-1999</div>
                        <div class="job_details">Attorney, Assigned Counsel and Guardian ad Litem. <li>Practiced in areas of Domestic Relations, Juvenile, Delinquency, Criminal, Bankruptcy and Probate Law. Minor role in Domestic Relations, Juvenile, Delinquency, Criminal and Probate Law. </li>


</div>
                      </div>                      
                    </div>

                    <div class="col-md-3 ">
                      <div class="skill_box">
                          <p class="skills">Skills</p>Litigation<br>Mediation services<br>Parenting Coordinator<br>Recovery Parenting<br><p></p>
                          <p class="skills">Mediation Certifications</p>Domestic Abuse Training<br>Family Law Training<br>Juvenile Court Training<br>Parenting Coordinator Training<br>
                    </div>
                    </div>
                  </div> <!-- End Work -->
              </div>

              <!-- Education  -->
              <div class="work">
                  <div class="row">
                    <div class="col-md-2 education_class "><h4>Education</h4></div>
                    <div class="col-md-7 ">
   <p class="skills">Professional Associations</p>

<li>Cleveland Metropolitan Bar Association<br>
<li>Ohio State Bar Association<br>
<li>Guardian Ad Litem Project of Cuyahoga County, Advisory Board Member<br>
<li>Guardian Ad Litem for Cuyahoga County Juvenile Drug Court<br>
<li>Licensed to practice in the Northern District of Ohio<br>
<li>Licensed to practice in the Federal Supreme Court of the United States<br>
<li>Member of Board of Directors of Promise Academy<br>
<li>Edwins Leadership & Restaurant Institute, Member of Board of Directors<br>
                    </div>
                    <div class="col-md-3 ">
                      <div class="skill_box">
                       
                  <div class="job">
                        
                        <div class="position_title"><a href="https://www.law.csuohio.edu/" target="_blank"><span class="color_3">Cleveland-Marshall College of Law</span></a></div>
                        <div class="company_title">Juris Doctor</div>
                        <div class="job_period">1988-1991</div>
                        <!--<div class="job_details">Specialty, interest in juvenille law</div>-->
                      </div>    

                      <div class="job">
                        <div class="position_title"><a href="https://www.ohio.edu/" target="_blank"><span class="color_3">Ohio University</span></a></div>
                        <div class="company_title">Bachelor of Science: Hearing and Speech Pathology</div>
                        <div class="job_period">1974-1977</div>
                        <!--<div class="job_details">Hearing and Speach speciality</div> -->
                      </div>
                    </div>
                    </div>
                  </div> <!-- End Education -->
              </div>

            </div>
          </div>
        </div>



<div class="container contentContainer contactPageTop" id="contactbox">

                  <div class="row">

                              <h2 id="contact" >CONTACT</h2>
                              <div class="col-md-6">


                             
                        
                              <p class="lead">Looking forward to answering your email</p>
                              <form method="post" action="#error-check" id="error-check">

                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Your name here" value="<?php echo $_POST['name']; ?>"/>
                                </div>

                                <div class="form-group">
                                    <label for="email">Email address</label>
                                    <input type="email" name="email" class="form-control" id="email" placeholder="Your email here" value="<?php echo $_POST['email']; ?>"/>
                                </div>

                                <div class="form-group">
                                    <label for="subject">Subject</label>
                                    <input type="text" name="subject" class="form-control" id="subject" placeholder="Your subject here" value="<?php echo $_POST['subject']; ?>">
                                </div>

                                <div class="form-group">
                                    <label for="message">Message</label>
                                    <textarea name="message" class="form-control" rows="3" placeholder="Your message here"><?php echo $_POST['message']; ?></textarea>
                                </div>

                                <input type="submit" name="submit" class="btn btn-default btn-lg pull-right" value="Submit"/>

                              </form>

                        </div>     


                        <div class="col-md-6" id="contact_links"style="width:200px;">                     
                              <a href="https://www.linkedin.com/in/cynthiabond" target="_blank"> <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-linkedin fa-stack-1x fa-inverse"></i></span> </a>
                              <!-- <a href="https://facebook.com/" target="_blank"> <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i>  <i class="fa fa-facebook fa-stack-1x fa-inverse"></i></span> </a> -->

                              <a href="https://twitter.com/cmbmorgan" target="_blank"> <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i>  <i class="fa fa-twitter fa-stack-1x fa-inverse"></i></span> </a>
                              <a href="mailto:me@Cynthiammorgan.com" target="_blank"> <span class="fa-stack fa-lg">  <i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-envelope-o fa-stack-1x fa-inverse"></i></span> </a>
                              <p><span id="email_id"></span> Cynthia@216Mediation.com</p>
                        </div>

                  </div>           
        </div>        



        <!--Fixed footer -->
        <div class="navbar navbar-default navbar-static-bottom footer clear-navbar-inner">
          <div class="container">
                <div class="row">

                    <div class="col-md-12 text-center copyright">
                          Copyright &copy; 2016 Cynthia Morgan. All Rights Reserved.
                    </div>
                    
                </div>
          </div>
        </div>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script>$(".contentContainer").css("min-height", $(window).height());</script>


    <!-- jQuery (necessary for scroll-up plugins) starts here-->
    <script src="js/jquery.scrollUp.min.js"></script>
    <script>

                    $(function () {
                        $.scrollUp({
                            animation: 'fade',
                            activeOverlay: '#FFFFFF',
                            scrollImg: {
                                active: true,
                                type: 'background',
                                src: 'images/top.png'
                            }
                        });
                    });
                    $('#scrollUpTheme').attr('href', 'css/image.css');
                    $('.image-switch').addClass('active');

    </script>
    <!-- jQuery (necessary for scroll-up plugins) ends here -->

    <!-- Scrolling Nav JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrolling-nav.js"></script>
    
    <!-- To leave any feedback, please visit http://www.Cynthiammorgan.com/ -->

  </body>




</html>
