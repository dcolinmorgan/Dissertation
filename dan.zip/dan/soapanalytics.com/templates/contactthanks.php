<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<head>
	<title>A Nice & Simple Contact Form</title>
	
	<link rel="stylesheet" type="text/css" href="../style/style2.css" />
</head>

<body>

	<div id="page-wrap">

		<img src="../images/SOAP.png" alt="A Nice & Simple Contact Form" />
		
			
			
		<br /><br />
		
			
		<h1>Your message has been sent!</h1><br />
		
		<p><a href="index.html">Back to Home Page</a></p>
	
	</div>
	
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
	</script>
	<script type="text/javascript">
	_uacct = "UA-68528-29";
	urchinTracker();
	</script>

</body>

</html>