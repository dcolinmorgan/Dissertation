    
    <div class="slider">

      <div class="slide active-slide">
        <div class="container">
          <div class="row">
            <div class="slide-copy col-xs-5">
              <h1>Soap Analytics Is Your Data Cleaning Center</h1>
              <h2>A single portal to collect, clean and collate your data.</h2>
              
              <ul class="get-app">
                <li><a href="#"><img src="images/EMBL-EBI.jpg"></a></li>
                <li><a href="#"><img src="images/uniprot.gif"></a></li>
                <li><a href="#"><img src="images/NCBI.png"></a></li>
                <li><a href="#"><img src="images/sprot.gif"></a></li>
                <li><a href="#"><img src="images/prosite.gif"></a></li>
                <li><a href="#"><img src="images/Oncomine.jpg"></a></li>
                <li><a href="#"><img src="images/pdb.png"></a></li>
                <li><a href="#"><img src="images/SMD.gif"></a></li>
                <li><a href="#"><img src="images/tcga.png"></a></li>
              </ul>
            </div>
            <div class="slide-img col-xs-7">
              <img src="images/analytics.jpg" width="540px">
            </div>
          </div>
        </div>      
      </div>

      <div class="slide slide-feature">
        <div class="container">
          <div class="row">
            <div class="col-xs-12">
              <a href="#"><img src="images/SOAP+GS.png"></a>
             
            </div>
            
          </div>
        </div>      
      </div> 

      <div class="slide">
        <div class="container">
          <div class="row">
            <div class="slide-copy col-xs-5">
              <h1>Enjoy Enhanced Statistical Power</h1>
              <p>Meta-analytic dataset meshing using the OpenSource R package BioConductor to power the engine behind the SOAP toolset.</p>
              
            </div>
            <div class="slide-img col-xs-7">
              <img src="images/cleanse.jpg">
            </div>
          </div>
        </div>      
      </div> 


      <div class="slide">
        <div class="container">
          <div class="row">
            <div class="slide-copy col-xs-5">
              <h1>Tools & Implementation</h1>
              <p>All too often disparate samples are collected and analyzed, their data stored in solitary repositories left for singular analysis. At SOAP, our aim and mission is to clean such datasets, enhancing them with domain specific knowledge in such a way to make interoperable calculation possible.</p>
              
              <ul class="get-app">
                <li><a href="#"><img src=""></a></li>
                <li><a href="#"><img src=""></a></li>
                <li><a href="#"><img src=""></a></li>
                <li><a href="#"><img src=""></a></li>
              </ul>
            </div>
            <div class="slide-img col-xs-7">
              <img src="images/clean_all_the_data.png" width="540px">
            </div>
          </div>
        </div>      
      </div> 

    </div>

    <div class="slider-nav">
    <script type="text/javascript" src="js/apps.js"></script>
      <a href="#" class="arrow-prev"><img src="images/arrow-prev.png"></a>
      <ul class="slider-dots">
        <li class="dot active-dot">&bull;</li>
        <li class="dot">&bull;</li>
        <li class="dot">&bull;</li>
        <li class="dot">&bull;</li>
      </ul>
      <a href="#" class="arrow-next"><img src="images/arrow-next.png"></a>
    </div> 

  </body>
</html>