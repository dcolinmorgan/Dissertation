<!DOCTYPE html>
<html>
  <head>
    <title>SoapAnalytics.com</title>
    <link href="favicon.ico" rel="shortcuticon">
    <link href="styles/shift.css" rel="stylesheet">
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <link href="styles/style.css" rel="stylesheet">
    <?php include 'analyticstracking.php' ?>
  </head>
  <body>
    <?php include_once("analyticstracking.php") ?>
    <link href="styles/style.css" rel="stylesheet">
    <link href="styles/bootstrap.min.css" rel="stylesheet">
    <link href="styles/bootstrap_responsive.css" rel="stylesheet">
    <script type="text/javascript" src="js/min.js"></script>
    <script type="text/javascript" src="js/alphabet.js"></script>


    <div class="header">
      <div class="nav">
      <link href="styles/style.css" rel="stylesheet">
      <ul class="pull-left">
        <li><a href="https://dl.dropboxusercontent.com/u/2483077/demoI.html">demo</a></li>
      </ul>
      <ul class="pull-right">
        <li><a href="?action=sign_up">Sign Up</a></li>
        <li><a href="?action=log_in">Log In</a></li>
        <li><a href="?action=blue_form.htm">Contact</a></li>
      </ul>
    </div>
    </div>
 

    <canvas id="myCanvas"></canvas>

    <script type="text/javascript" src="js/bubbles.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
    </div>
